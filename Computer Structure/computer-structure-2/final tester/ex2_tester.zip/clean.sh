rm *_*_*.bin
make clean