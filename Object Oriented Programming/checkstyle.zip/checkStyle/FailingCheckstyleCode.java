/**
 * this is the FailingCheckstyleCode class.
 */
public class FailingCheckstyleCode {
 /**
  * this is the main function.
  * @param args is the main default syntax.
  */
 public static void main(String[] args) {
   for (int i = 0; i < 5; i++) {
    System.out.println("I is " + i);
   }
  }
}